"""
Dashboard Routes — Feed, Stats, Leaderboard
"""
from fastapi import APIRouter
from database import (feed_items, users, runner_requests, cab_pools,
                      marketplace_listings, get_leaderboard, time_ago, mess_menus)
from datetime import datetime

router = APIRouter()

DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]


@router.get("/feed")
def get_feed():
    items = []
    for f in feed_items[:20]:
        items.append({**f, "time_ago": time_ago(f["time"])})
    return {"feed": items}


@router.get("/stats")
def get_stats():
    return {
        "active_requests": sum(1 for r in runner_requests.values() if r["status"] == "open"),
        "cab_pools": sum(1 for c in cab_pools.values() if c["status"] == "open"),
        "market_listings": sum(1 for m in marketplace_listings.values() if m["status"] == "available"),
        "total_users": len(users),
    }


@router.get("/leaderboard")
def leaderboard():
    return {"leaderboard": get_leaderboard()}


@router.get("/today-mess")
def today_mess(hostel: str = "H12"):
    day = DAYS[datetime.utcnow().weekday()]
    menu = mess_menus.get(hostel, {}).get(day, mess_menus.get(hostel, {}).get("Wednesday", {}))
    return {"hostel": hostel, "day": day, "menu": menu}