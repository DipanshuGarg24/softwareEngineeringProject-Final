"""
Groups & Events Routes
"""
from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from typing import Optional
from database import groups_data, events_data, users, sessions, new_id, now_iso, get_user_safe, add_feed

router = APIRouter()


def _get_uid(auth: str) -> str:
    token = auth.replace("Bearer ", "").strip()
    uid = sessions.get(token)
    if not uid: raise HTTPException(401, "Not authenticated")
    return uid


class GroupCreate(BaseModel):
    name: str
    description: str = ""
    type: str = "public"


class EventCreate(BaseModel):
    title: str
    description: str = ""
    date: str
    location: str = ""


def _enrich_group(g: dict) -> dict:
    creator = get_user_safe(g["creator_id"])
    member_list = [get_user_safe(uid) for uid in g["members"]]
    group_events = [e for e in events_data.values() if e["group_id"] == g["id"]]
    for e in group_events:
        e["rsvp_count"] = len(e.get("rsvp", []))
    return {
        **g,
        "creator_name": creator.get("name", ""),
        "member_count": len(g["members"]),
        "member_list": member_list,
        "events": sorted(group_events, key=lambda x: x.get("date", "")),
    }


@router.get("/")
def list_groups():
    results = [_enrich_group(g) for g in groups_data.values()]
    return {"groups": results}


@router.post("/")
def create_group(group: GroupCreate, authorization: str = Header(default="")):
    uid = _get_uid(authorization)
    gid = new_id()
    groups_data[gid] = {
        "id": gid, "name": group.name, "description": group.description,
        "type": group.type, "creator_id": uid,
        "members": [uid], "created_at": now_iso(),
    }
    return {"message": "Created", "group": _enrich_group(groups_data[gid])}


@router.get("/{gid}")
def get_group(gid: str):
    g = groups_data.get(gid)
    if not g: raise HTTPException(404, "Not found")
    return _enrich_group(g)


@router.put("/{gid}/join")
def join_group(gid: str, authorization: str = Header(default="")):
    uid = _get_uid(authorization)
    g = groups_data.get(gid)
    if not g: raise HTTPException(404, "Not found")
    if uid in g["members"]: raise HTTPException(400, "Already a member")
    g["members"].append(uid)
    return {"message": "Joined", "group": _enrich_group(g)}


@router.put("/{gid}/leave")
def leave_group(gid: str, authorization: str = Header(default="")):
    uid = _get_uid(authorization)
    g = groups_data.get(gid)
    if not g: raise HTTPException(404, "Not found")
    if uid not in g["members"]: raise HTTPException(400, "Not a member")
    if uid == g["creator_id"]: raise HTTPException(400, "Creator can't leave")
    g["members"].remove(uid)
    return {"message": "Left"}


@router.post("/{gid}/events")
def create_event(gid: str, event: EventCreate, authorization: str = Header(default="")):
    uid = _get_uid(authorization)
    g = groups_data.get(gid)
    if not g: raise HTTPException(404, "Group not found")
    if uid not in g["members"]: raise HTTPException(403, "Must be a member")
    eid = new_id()
    events_data[eid] = {
        "id": eid, "group_id": gid, "title": event.title,
        "description": event.description, "date": event.date,
        "location": event.location, "rsvp": [uid], "created_by": uid,
    }
    name = users[uid]["name"]
    add_feed("fa-calendar", "#7c3aed", "#ede9fe",
             f"<b>{name}</b> created event: <b>{event.title}</b> in {g['name']}.", "event")
    return {"message": "Created", "event": events_data[eid]}


@router.put("/events/{eid}/rsvp")
def rsvp_event(eid: str, authorization: str = Header(default="")):
    uid = _get_uid(authorization)
    e = events_data.get(eid)
    if not e: raise HTTPException(404, "Event not found")
    if uid in e["rsvp"]:
        e["rsvp"].remove(uid)
        return {"message": "RSVP removed", "rsvp_count": len(e["rsvp"]), "is_going": False}
    e["rsvp"].append(uid)
    return {"message": "RSVP confirmed", "rsvp_count": len(e["rsvp"]), "is_going": True}
